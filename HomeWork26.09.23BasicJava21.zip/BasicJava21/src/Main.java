public class Main {
    public static void main(String[] args) {
        System.out.println("Hallo!");
        System.out.println("Ich bin Mihaela.");
        System.out.println("2 + 2");
        System.out.println("2" + "2");
        System.out.println(2 + 2);
        System.out.println("2" + 2);
        System.out.println(2 + "2");
        System.out.println(2 + 2 + "2");
        System.out.println("2" + 2 + 2);
    }
}