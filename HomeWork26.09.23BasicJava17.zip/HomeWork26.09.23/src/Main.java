public class Main {
    public static void main(String[] args) {
        System.out.print("Hello, ");
        System.out.print("my ");
        System.out.print("name ");
        System.out.print("is ");
        System.out.print("<Mihaela>!");
    }
}